<?php
return [
"checkAuth"
];