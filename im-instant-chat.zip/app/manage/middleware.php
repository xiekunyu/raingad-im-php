<?php
return [
"checkAuth",
"manageAuth"
];